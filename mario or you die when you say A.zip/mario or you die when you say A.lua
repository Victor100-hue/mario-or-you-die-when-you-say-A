-- name:Mario/you die when you say the \\#f0000#\\ A
-- Description: this mod is for fun and for thats people spam the A recommend:) credits to anti Beta mod creator :) and i want you a good life you not be a really bad person continue modding not let be stopped of the critic continue your life:)

Localkillerwords:)
    "a",
    "Á",
    "Aaaaaaa",
    "Ooooaaaaa?",
    "Aaaaaaoaoaoa",
    "Ą",
    "Aâ",

 }
function killbeytah(m, msg)
    msg = msg:lower()
    for _, word in pairs(killwords) do
        if msg:find(word) then
            spawn_sync_object(id_bhvExplosion, E_MODEL_EXPLOSION, m.pos.x, m.pos.y, m.pos.z, nil)
            set_mario_action(m, ACT_DISAPPEARED, 0)
            level_trigger_warp(m, WARP_OP_DEATH)
            return true
        end
    end
    return true
end
hook_event(HOOK_ON_CHAT_MESSAGE, killbeytah)
